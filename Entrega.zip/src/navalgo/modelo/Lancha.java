package navalgo.modelo;

public class Lancha extends Barco {
	
	public Lancha(Punto posicion, Orientacion orientacion, int direccionX,  int direccionY) {
		super(posicion, orientacion, 2, 1, direccionX, direccionY, "Lancha");
		
	}


	
}

