package navalgo.modelo;

public interface EstrategiaDireccion {
	public Direccion execute();
}
