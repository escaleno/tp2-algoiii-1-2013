package navalgo.modelo;

public class Portaavion extends Barco {
	
	public Portaavion(Punto posicion, Orientacion orientacion, int direccionX,  int direccionY) {
		super(posicion, orientacion, 5, 1, direccionX, direccionY, "PortaAvion");
	}

	


}
