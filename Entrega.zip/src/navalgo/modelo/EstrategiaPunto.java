package navalgo.modelo;

public interface EstrategiaPunto {
	public Punto execute();
}
