package navalgo.modelo;

public class PosicionInvalidaException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
}
