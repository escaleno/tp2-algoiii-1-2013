package navalgo.modelo;

public class Rompehielos extends Barco {
	
	public Rompehielos(Punto posicion, Orientacion orientacion, int direccionX,  int direccionY) {
		super(posicion, orientacion, 3, 2, direccionX, direccionY, "RompeHielos");
	}

}
