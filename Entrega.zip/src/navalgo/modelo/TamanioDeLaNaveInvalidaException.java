package navalgo.modelo;

public class TamanioDeLaNaveInvalidaException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
}
