package navalgo.modelo;

public interface EstrategiaOrientacion {
	public Orientacion execute();
}
